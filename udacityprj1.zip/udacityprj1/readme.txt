to fix datetimeproperties error 
https://stackoverflow.com/questions/60214194/error-in-reading-stock-data-datetimeproperties-object-has-no-attribute-week



to retrieve random sample data:
https://nfpdiscussions.udacity.com/t/data-frame-sample-method/60220/5

https://nfpdiscussions.udacity.com/t/problem-showing-the-sample-data-if-requested-bike-share-project/26827/2

https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.sample.html

to add an image:
https://anaconda.org/anaconda/pillow
http://zetcode.com/python/pillow/
