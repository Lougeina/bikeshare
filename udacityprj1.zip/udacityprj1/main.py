import time
import pandas as pd
import numpy as np
from PIL import Image
import sys


CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    print('Greetings! Let\'s explore 2017 US bikeshare data at a glance!')
    try:
        bikes = Image.open("bikes.jpg")

    except IOError:
        print("Unable to load image")
        sys.exit(1)

    bikes.show()

    # get user input for city (chicago, new york city, washington).
    city = input("Which city would you like to explore?  1: Chicago, 2: New york, 3: Washington \n")
    cities = pd.Series(data = ['chicago', 'new york city', 'washington'], index = ['1','2','3'] )
    while city not in cities:
        city = input("Please Enter the Corresponding number: ")
    else:
        cities[city]

    # get user input for month (all, january, february, ... , june)
    month = input("Which month would you like to view?  1: January, 2: February, 3: March, 4: April, 5: May, 6: June, 7: all \n")
    months = pd.Series(data=['january', 'february', 'march', 'april', 'may', 'june','all'], index = ['1','2','3','4','5','6','7'])
    while month not in months:
        month = input("Please Enter the Corresponding number: ")
    else:
        months[month]

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day = input("Which day would you like to view?  1: Sunday, 2: Monday, 3: Tuesday, 4: Wednesday, 5: Thursday, 6: Friday, 7: Saturday, 8: all \n")
    days = pd.Series(data=['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'all'],index = ['1','2','3','4','5','6','7','8'])
    while day not in days:
        day = input("Please Enter the Corresponding number: ")
    else:
        days[day]

    print('-'*40)
    return cities[city], months[month], days[day]




def load_data(city, month, day):

    # load data file into a dataframe
    df = pd.read_csv(CITY_DATA[city])

    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # extract month and day of week from Start Time to create new columns
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()

    # extract hour from the Start Time column to create an hour column'
    df['hour'] = df['Start Time'].dt.hour

    # filter by month if applicable
    if month != 'all':
        # use the index of the months list to get the corresponding int
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month) + 1

        # filter by month to create the new dataframe
        df = df[df['month'] == month]

    elif month == 'all':
        df['month'] = df['Start Time'].dt.month

    # filter by day of week if applicable
    if day != 'all':
        # filter by day of week to create the new dataframe
        df = df[df['day_of_week'] == day.title()]

    elif day == 'all':
        df['day_of_week'] = df['Start Time'].dt.day_name()

    return df


def time_stats(df, month, day):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    if month =="all":
        # display the most common month
        months_set = pd.Series(data= ['January', 'February', 'March', 'April', 'May', 'June'], index=[1,2,3,4,5,6] )
        popular_month = df['month'].mode()[0]
        print('Most Frequent Start Month:', months_set[popular_month])
    else:
        print("You filtered by ", month)

    if day == "all":
        # display the most common day of week
        popular_day = df['day_of_week'].mode()[0]
        print('Most Frequent Start Day:', popular_day)
    else:
        print("You filtered by ", day)

    # display the most common start hour
    popular_hour = df['hour'].mode()[0]
    print('Most Frequent Start Hour:', popular_hour, "O'clock")


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most frequent combination of start station and end station trip
     # display most commonly used start station
    total_start = df['Start Station'].mode()[0]
    print('Most Frequent Start Station: ', total_start)

    # display most commonly used end station
    total_end = df['End Station'].mode()[0]
    print('Most Frequent End Station: ', total_end)

    # display most frequent combination of start station and end station trip
    df["trip"] = df["Start Station"] + ' :to: ' + df["End Station"]
    most_freq_trip = df["trip"].mode()[0]
    print("Most Commmon Trip: ", most_freq_trip)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    total_time = df['Trip Duration'].sum()
    print("Total traveled time; ", total_time, " Hours")

    # display mean travel time
    avg_time = df['Trip Duration'].mean()
    print("Average traveled time; ", avg_time, " Hours per Trip")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_types = df['User Type'].value_counts()
    print("Types of Users:\n", user_types)

    # Display counts of gender
    try:
        gender = df['Gender'].value_counts()
        print("Different Genders:\n", gender)

    # Display earliest, most recent, and most common year of birth
        earliest = df['Birth Year'].min()
        print("Eldest User born in: ", np.int64(earliest))

        recent=  df['Birth Year'].max()
        print("Youngest User born in: ", np.int64(recent))

        common= df['Birth Year'].mode()[0]
        print("Most Common Birth Year: ", np.int64(common))

    except KeyError:
            print("Gender and age data is not available for Washington")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)




def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df, month, day)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        datasample = input("Would you like to view data samples? Enter yes or no. \n")
        while datasample.lower() == "yes":
            print(df.sample(n=5))
            datasample = input("Would you like to view more data samples? Enter yes or no. \n")
            if datasample != 'yes':
                print("Okay, that would be it")
                break

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            print("Thank You, Goodbye")
            break



if __name__ == "__main__":
	main()
